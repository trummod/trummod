package org.koitharu.kotatsu.favourites.ui.categories

interface AllCategoriesToggleListener {

	fun onAllCategoriesToggle(isVisible: Boolean)
}