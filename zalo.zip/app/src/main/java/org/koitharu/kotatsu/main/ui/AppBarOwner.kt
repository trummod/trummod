package org.koitharu.kotatsu.main.ui

import com.google.android.material.appbar.AppBarLayout

interface AppBarOwner {

	val appBar: AppBarLayout
}