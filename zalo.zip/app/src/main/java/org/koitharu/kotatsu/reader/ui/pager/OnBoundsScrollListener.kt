package org.koitharu.kotatsu.reader.ui.pager

interface OnBoundsScrollListener {

	fun onScrolledToStart()

	fun onScrolledToEnd()
}