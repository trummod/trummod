package org.koitharu.kotatsu.list.ui.model

object LoadingState : ListModel