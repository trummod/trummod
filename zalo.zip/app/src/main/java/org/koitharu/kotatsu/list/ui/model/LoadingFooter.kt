package org.koitharu.kotatsu.list.ui.model

object LoadingFooter : ListModel