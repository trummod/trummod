package org.koitharu.kotatsu.core.exceptions

import java.io.IOException

class UnsupportedFileException(message: String? = null) : IOException(message)