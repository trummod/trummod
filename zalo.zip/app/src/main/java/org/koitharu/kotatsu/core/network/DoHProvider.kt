package org.koitharu.kotatsu.core.network

enum class DoHProvider {

	NONE, GOOGLE, CLOUDFLARE, ADGUARD
}