package org.koitharu.kotatsu.list.ui.model

interface ListModel