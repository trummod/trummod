package org.koitharu.kotatsu.utils.ext

fun Throwable.printStackTraceDebug() = printStackTrace()