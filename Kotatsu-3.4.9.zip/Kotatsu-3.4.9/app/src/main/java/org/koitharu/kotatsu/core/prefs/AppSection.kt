package org.koitharu.kotatsu.core.prefs

enum class AppSection {

	LOCAL, FAVOURITES, HISTORY, FEED, SUGGESTIONS
}