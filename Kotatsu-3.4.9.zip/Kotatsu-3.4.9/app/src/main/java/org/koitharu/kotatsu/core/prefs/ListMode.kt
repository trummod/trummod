package org.koitharu.kotatsu.core.prefs

enum class ListMode {

	LIST, DETAILED_LIST, GRID;
}