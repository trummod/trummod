package org.koitharu.kotatsu.scrobbling.domain.model

class ScrobblerMangaInfo(
	val id: Long,
	val name: String,
	val cover: String,
	val url: String,
	val descriptionHtml: String,
)