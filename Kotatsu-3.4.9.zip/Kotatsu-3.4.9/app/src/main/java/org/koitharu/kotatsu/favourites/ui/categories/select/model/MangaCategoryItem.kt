package org.koitharu.kotatsu.favourites.ui.categories.select.model

data class MangaCategoryItem(
	val id: Long,
	val name: String,
	val isChecked: Boolean
)