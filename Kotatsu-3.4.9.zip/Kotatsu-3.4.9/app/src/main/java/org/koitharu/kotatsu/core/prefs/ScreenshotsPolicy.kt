package org.koitharu.kotatsu.core.prefs

enum class ScreenshotsPolicy {

	// Do not rename this
	ALLOW, BLOCK_NSFW, BLOCK_ALL;
}