package org.koitharu.kotatsu.base.ui

import androidx.lifecycle.LifecycleService

abstract class BaseService : LifecycleService()