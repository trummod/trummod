package org.koitharu.kotatsu.core.exceptions

class EmptyHistoryException : RuntimeException()